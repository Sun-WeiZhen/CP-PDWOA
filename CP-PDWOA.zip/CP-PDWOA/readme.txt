1��It should be noted that this article has been modified based on the original WOA algorithm.
2��We added perturbation ideas to the algorithm��
3��We discussed the impact of the search path on the algorithm
4��When you run WOA you can see the optimization effect of a single function
5��The comparison of all experiments is in the result��a folder ��