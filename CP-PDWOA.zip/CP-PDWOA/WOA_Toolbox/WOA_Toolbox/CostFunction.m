
function Cost = CostFunction( x )
dim=size(x,2);
Cost=sum(x.^2); 
end

