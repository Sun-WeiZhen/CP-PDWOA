clc
load ajimide.txt;
load duishu.txt;
load waibai.txt;
load yuannei.txt;
load yuanwai.txt;
figure(1)
semilogy(ajimide,'r-.')
hold on 
semilogy(duishu,'b-.')
hold on
semilogy(waibai,'b--')
hold on 
semilogy(yuannei,'r-')
hold on
semilogy(yuanwai,'k')
hold on 
legend('ajimide','duishi','waibai','yuannei','yuanwai')
xlabel('Iteration');
ylabel('Best score obtained so far');