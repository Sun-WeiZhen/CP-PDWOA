clc
load ajimide.txt;
load duishu.txt;
load waibai.txt;
load yuannei.txt;
load yuanwai.txt;
figure(1)
semilogy(ajimide(1:200,:),'r-.')
hold on 
semilogy(duishu(1:200,:),'b-.')
hold on
semilogy(waibai(1:200,:),'b--')
hold on 
semilogy(yuannei(1:200,:),'r-')
hold on
semilogy(yuanwai,'k')
hold on 
legend('ajimide','duishi','waibai','yuannei','yuanwai')
xlabel('Iteration');
ylabel('Best score obtained so far');
